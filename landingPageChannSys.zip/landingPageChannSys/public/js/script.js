const siteLists = document.querySelectorAll(".various-site ul li a");
const header = document.querySelector("header");
const headerImg = document.querySelector("header img");
const myProject = document.querySelector(".my-project");
const socialMedias = document.querySelectorAll(".social-media ul li");

setTimeout(() => {
	siteLists.forEach((item, i) => {
		gsap.fromTo(
			item,
			{ translateY: -100, duration: 1, delay: i * 0.3 },
			{ translateY: 0, duration: 1, delay: i * 0.3, opacity: 1 }
		);
	});
}, 1500);

header.childNodes.forEach((item, i) => {
	gsap.to(headerImg, {
		rotateY: 360,
		duration: 2,
	});

	gsap.from(item, {
		translateY: -100,
		duration: 1,
		delay: i * 0.2,
		opacity: 0,
	});
});

setTimeout(() => {
	myProject.childNodes.forEach((item, i) => {
		gsap.fromTo(
			item,
			{ translateY: -100, duration: 0.8, delay: i * 0.3 },
			{ translateY: 0, duration: 0.8, delay: i * 0.3, opacity: 1 }
		);
	});
}, 2000);

setTimeout(() => {
	socialMedias.forEach((item, i) => {
		gsap.fromTo(
			item,
			{ translateY: -100, duration: 1, delay: i * 0.3 },
			{ translateY: 0, duration: 1, delay: i * 0.3, opacity: 1 }
		);
	});
}, 2500);
